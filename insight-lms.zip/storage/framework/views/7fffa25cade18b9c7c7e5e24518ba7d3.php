<?php $__env->startSection('page_header', __('profile')); ?>
<?php $__env->startSection('app'); ?>
<div class="card mb-3">
    <div class="card-body">
        <div class="mb-2">
            <label for="" class="form-label">Есімі</label>
            <input type="text" class="form-control" value="<?php echo e(Auth::user()->first_name); ?>">
        </div>
        <div class="mb-2">
            <label for="" class="form-label">Тегі</label>
            <input type="text" class="form-control" value="<?php echo e(Auth::user()->last_name); ?>">
        </div>
        <button class="btn btn-primary">Сақтау</button>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="mb-2">
            <label for="" class="form-label">Құпиясөз</label>
            <input type="password" class="form-control" value="<?php echo e(Auth::user()->first_name); ?>">
        </div>
        <div class="mb-2">
            <label for="" class="form-label">Құпиясөзді растау</label>
            <input type="password" class="form-control" value="<?php echo e(Auth::user()->last_name); ?>">
        </div>
        <button class="btn btn-primary">Сақтау</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\dton\insight-lms\resources\views/user/profile.blade.php ENDPATH**/ ?>