<?php $__env->startSection('page_header', __('rating')); ?>
<?php $__env->startSection('app'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\dton\insight-lms\resources\views/rating/index.blade.php ENDPATH**/ ?>