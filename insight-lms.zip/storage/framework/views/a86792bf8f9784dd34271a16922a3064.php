<!doctype html>
<html lang="<?php echo $__env->yieldContent('lang', 'EN'); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php if(config('telegram-webapp.enabled')): ?>
        <script id="telegram-webapp-script" src="<?php echo e(config('telegram-webapp.webAppScriptLocation')); ?>"></script>
    <?php endif; ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('head'); ?>
    <title><?php echo $__env->yieldContent('title', 'Telegram WebApp'); ?></title>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH D:\OSPanel\dton\insight-lms\vendor\micromagicman\laravel-telegram-webapp\src/../resources/views/main.blade.php ENDPATH**/ ?>