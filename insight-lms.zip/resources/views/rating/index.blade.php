@extends('layouts.app')
@section('page_header', __('rating'))
@section('app')

@endsection
