<?php

use Micromagicman\TelegramWebApp\TelegramWebAppServiceProvider;

return [
    App\Providers\AppServiceProvider::class,
];
